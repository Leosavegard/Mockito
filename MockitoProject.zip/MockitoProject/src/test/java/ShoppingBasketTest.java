import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class ShoppingBasketTest {


    ShoppingBasket basket;
    ProductDAO productDAO;




    @BeforeEach
    void setUp() {

        productDAO = new MockDAO();
        this.basket = new ShoppingBasket();
        this.basket.setProductDAO(productDAO);

    }

    @Test
    void testAddByName() {
        int count = 2;
        basket.addByName(count,"iphone");
        Product p = productDAO.findByName("iphone");
        int expectedPrice = (p.getPrice()*count);
        assertEquals(6000, expectedPrice);
    }

    @Test
    void testAddByName2() {
        basket.addByName(2,"iphone");
        assertEquals(6000, basket.getTotalCost());
    }

    @Test
    void testAddWithWrongName(){
        assertThrows(IllegalArgumentException.class, ()->basket.addByName(2,"huawei") );
    }

    @Test
    void testAddWithWrongByID(){
        assertThrows(IllegalArgumentException.class, () -> basket.addById(10,4));
    }

    @Test
    void addById() {
        basket.addById(3,1);
        Product p = productDAO.findById(1);
        assertEquals(9000,(p.getPrice()*3));
    }

    @Test
    void addById2() {
        basket.addById(3,1);
        assertEquals(9000,basket.getTotalCost());
    }

    @Test
    void getTotalCost() {
        basket.addById(1,1);
        assertEquals(3000,basket.getTotalCost());
    }

    @Test
    void getTotalCost2() {
        basket.addByName(3,"samsung");
        assertEquals(30000,basket.getTotalCost());
    }

    @Test
    void clear() {
        basket.addById(100,1);
        basket.clear();
        assertEquals(0,basket.getTotalCost());
    }

    @Test
    void testToString() {

        int count = 1;
        String name = "iphone";

        basket.addByName(count,name);
        String toString = basket.toString();

        assertTrue(toString.contains("[" + count + "*" + name + "]"));

    }
}