import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

import static org.junit.jupiter.api.Assertions.*;

class ShoppingBasketTestWithMockito {
    ShoppingBasket basket;
    ProductDAO productDAO;


    @BeforeEach
    void setUp() {
        productDAO = mock(ProductDAO.class);
        this.basket = new ShoppingBasket();
        this.basket.setProductDAO(productDAO);

        when(productDAO.findById(1)).thenReturn(new Product(1, "iphone", 3000));
        when(productDAO.findById(2)).thenReturn(new Product(2, "samsung", 10000));
        when(productDAO.findByName("iphone")).thenReturn(new Product(1, "iphone", 3000));
        when(productDAO.findByName("samsung")).thenReturn(new Product(2, "samsung", 10000));
        when(productDAO.findById(3)).thenReturn(null);
        when(productDAO.findByName("nokia")).thenReturn(null);
    }

    @Test
    void addByName() {
        basket.addByName(1, "samsung");
        assertEquals(10000, basket.getTotalCost());
    }


    @Test
    void addById() {
        basket.addById(1, 3);
        assertEquals(3000, basket.getTotalCost());

    }

    @Test
    void addByWrongID() {

        assertThrows(IllegalArgumentException.class, () -> basket.addById(1, 3));

    }


    @Test
    void addByWrongName() {

        assertThrows(IllegalArgumentException.class, () -> basket.addByName(1, "nokia"));

    }

    @Test
    void getTotalCost() {
        basket.addById(1,1);
        assertEquals(3000,basket.getTotalCost());
    }

    @Test
    void clear() {
        basket.addById(10,2);
        basket.clear();
        assertEquals(0,basket.getTotalCost());
    }
}