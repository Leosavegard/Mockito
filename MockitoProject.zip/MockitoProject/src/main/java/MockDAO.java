import java.util.List;

public class MockDAO implements ProductDAO {

    Product iphone = new Product(1, "iphone", 3000);
    Product samsung = new Product(2,"samsung", 10000);
    @Override
    public Product findById(int id) {

        if (iphone.getId() == id)
            return iphone;
        if (samsung.getId()==id )
            return samsung;
        else return null;
    }

    @Override
    public Product findByName(String name) {
        if (name.equalsIgnoreCase(iphone.getName()))
            return iphone;
        if (name.equalsIgnoreCase(samsung.getName()))
            return samsung;
        else return null;

    }

    @Override
    public List<Product> findAll() {
        return null;
    }

    @Override
    public List<Product> findCheaperThan(int lowprice) {
        return null;
    }

    @Override
    public boolean isInStock(int id) {
        return false;
    }

    @Override
    public boolean delete(int id) {
        return false;
    }

    @Override
    public void raiseAllPrices(double percent) {

    }
}
